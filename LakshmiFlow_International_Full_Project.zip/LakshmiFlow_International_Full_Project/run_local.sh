#!/usr/bin/env bash
set -e
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
export LAKSHMIFLOW_SECRET="$(python -c 'import secrets; print(secrets.token_urlsafe(48))')"
export COOKIE_SECURE=0
python app/server.py
