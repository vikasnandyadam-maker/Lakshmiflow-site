# Remaining enterprise modules and verified delivery boundary

The local project provides working persistence for the workflows listed in README. The following requested enterprise capabilities still need external services, additional implementation and acceptance testing:
- MFA / TOTP or passkeys, password reset and staff invitation lifecycle.
- Advanced role/permission matrix with field-level restrictions and full audit review.
- Full employee self-service dashboard, digital ID card, document vault and policy acknowledgements.
- Leave balances and configurable leave accrual rules; payroll and payslips after approved salary/statutory rules.
- Calendar availability synchronization, time-zone conversions, double-booking locks and video meeting creation.
- SMTP/transactional email notifications and WhatsApp Business API (the current WhatsApp link is a user-initiated external link).
- CRM company/contact enrichment from licensed sources, consent tracking and unsubscribe.
- AI assistant / AI content generation with verified knowledge base, owner review and prompt injection controls.
- Translation workflow with technical-spec preservation and reviewer approval.
- Analytics geo aggregation, consent management, exports and conversion attribution.
- Malware scanning, antivirus quarantine, signed private download URLs, production PostgreSQL migration, backup/restore drills, monitoring and independent security testing.

Do not describe these integrations as live until connected and tested. Product standards and engineering claims require certificates/test reports for the exact model/SKU.
