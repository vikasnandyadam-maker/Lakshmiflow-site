# LakshmiFlow International — Full Project Package

## Run locally
Requirements: Python 3.10+.

```bash
cd LakshmiFlow_International_Full_Project
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
export LAKSHMIFLOW_SECRET="$(python -c 'import secrets; print(secrets.token_urlsafe(48))')"
python app/server.py
```
Open:
- Public website: http://127.0.0.1:5000/
- Owner console: http://127.0.0.1:5000/admin.html
- Careers: http://127.0.0.1:5000/careers.html
- Health: http://127.0.0.1:5000/api/health

On first use, create the Owner account in the admin console. Use a unique password of at least 14 characters. Do not reuse a password. Never send credentials in chat.

## Included in this build
- Original supplied luxury website retained, with a backend bridge for B2B inquiry submission and basic page/WhatsApp event capture.
- Flask API + SQLite persistence.
- First-owner bootstrap, hashed passwords, server-side session, role checks, secure cookie settings configurable for HTTPS.
- B2B inquiries, pipeline status, product creation/listing, meeting requests, careers/jobs/applications.
- Employee records, attendance check-in/out, leave requests/review, tasks.
- PDF catalogue upload and public download after publishing.
- Basic event analytics and admin overview.
- Admin console and public careers/application page.
- Initial database schema also included under `database/schema_starter.sql`.

## Important honest status
This is a functional local full-stack foundation, not a fully audited enterprise production system. MFA, automated emails, Zoom/Google Calendar OAuth, payroll calculations, advanced HR policy engine, AI provider, translations, CRM contact discovery, Excel/PDF analytics exports, malware scanning, backup automation, database row-level policies and independent penetration testing are not integrated. The current app uses SQLite and a single-process Flask server; migrate to managed PostgreSQL and production WSGI hosting before public launch.

The original HTML used a browser-side Owner Studio approach. This package does not certify that legacy Owner Studio as secure. Use the server-side admin console for protected operations and remove/disable any old client-side login/password gate before public deployment. Rotate any password ever placed in HTML or JavaScript.

## Before production
1. Set strong `LAKSHMIFLOW_SECRET` in hosting secrets and `COOKIE_SECURE=1`.
2. Use HTTPS, managed PostgreSQL, private object storage, email provider and tested backups.
3. Add MFA, audit/alerting, CSRF protection, rate limiting, file malware scanning, retention/consent controls and security review.
4. Verify all technical performance/certification statements and catalogue PDFs before publishing.
5. Connect approved Calendar/Zoom/Meet, email and AI accounts through OAuth/secrets manager; no credentials are included.
6. Perform accessibility, load, mobile, privacy and end-to-end acceptance tests.

## Brand
Lakshmiflow International · Hyderabad, Telangana, India
info@lakshmiflowinternational.company · +91 6300233466
