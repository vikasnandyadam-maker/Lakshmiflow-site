import os, re, json, sqlite3, secrets, hashlib, hmac, time
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
from flask import Flask, request, jsonify, session, send_from_directory, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

ROOT = Path(__file__).resolve().parent.parent
DB = Path(os.environ.get("LAKSHMIFLOW_DB", ROOT/"instance"/"lakshmiflow.sqlite3"))
UPLOADS = Path(os.environ.get("LAKSHMIFLOW_UPLOADS", ROOT/"instance"/"uploads"))
UPLOADS.mkdir(parents=True, exist_ok=True)
app = Flask(__name__, static_folder=None)
app.secret_key = os.environ.get("LAKSHMIFLOW_SECRET") or secrets.token_hex(32)
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE","0")=="1",
                  MAX_CONTENT_LENGTH=25*1024*1024, PERMANENT_SESSION_LIFETIME=3600)
ROLES = ["owner","hr","sales","export","product","marketing","support","finance","employee"]
def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init_db():
    with db() as c:
        c.executescript("""
        PRAGMA foreign_keys=ON;
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL, name TEXT NOT NULL, role TEXT NOT NULL, active INTEGER DEFAULT 1, created TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS inquiries(id INTEGER PRIMARY KEY, name TEXT NOT NULL, company TEXT, email TEXT NOT NULL, country TEXT, port TEXT, product TEXT, quantity TEXT, message TEXT, status TEXT DEFAULT 'new', assigned_to INTEGER, created TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY, category TEXT NOT NULL, name TEXT NOT NULL, model TEXT, finish TEXT, dimensions TEXT, specs TEXT, description TEXT, published INTEGER DEFAULT 0, created TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS media(id INTEGER PRIMARY KEY, product_id INTEGER, filename TEXT NOT NULL, original_name TEXT, mimetype TEXT, created TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(product_id) REFERENCES products(id));
        CREATE TABLE IF NOT EXISTS catalogues(id INTEGER PRIMARY KEY, title TEXT NOT NULL, volume TEXT, filename TEXT NOT NULL, published INTEGER DEFAULT 0, created TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS meetings(id INTEGER PRIMARY KEY, name TEXT NOT NULL, company TEXT, email TEXT NOT NULL, country TEXT, purpose TEXT, preferred_at TEXT, requirements TEXT, status TEXT DEFAULT 'pending', created TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS employees(id INTEGER PRIMARY KEY, user_id INTEGER UNIQUE, employee_code TEXT UNIQUE NOT NULL, department TEXT, designation TEXT, joining_date TEXT, work_mode TEXT DEFAULT 'hybrid', status TEXT DEFAULT 'active', FOREIGN KEY(user_id) REFERENCES users(id));
        CREATE TABLE IF NOT EXISTS leave_requests(id INTEGER PRIMARY KEY, employee_id INTEGER NOT NULL, leave_type TEXT, start_date TEXT, end_date TEXT, reason TEXT, status TEXT DEFAULT 'pending', reviewed_by INTEGER, created TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(employee_id) REFERENCES employees(id));
        CREATE TABLE IF NOT EXISTS attendance(id INTEGER PRIMARY KEY, employee_id INTEGER NOT NULL, check_in TEXT, check_out TEXT, work_mode TEXT, note TEXT, created TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(employee_id) REFERENCES employees(id));
        CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY, title TEXT NOT NULL, details TEXT, assigned_employee INTEGER, priority TEXT DEFAULT 'normal', due_date TEXT, status TEXT DEFAULT 'open', outcome TEXT, created TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY, title TEXT NOT NULL, department TEXT, location TEXT, work_mode TEXT, description TEXT, active INTEGER DEFAULT 1, created TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS applications(id INTEGER PRIMARY KEY, job_id INTEGER, name TEXT NOT NULL, email TEXT NOT NULL, phone TEXT, education TEXT, experience TEXT, skills TEXT, expected_salary TEXT, availability TEXT, cv_filename TEXT, status TEXT DEFAULT 'received', notes TEXT, created TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, user_id INTEGER, action TEXT NOT NULL, entity TEXT, entity_id INTEGER, ip TEXT, created TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, event TEXT NOT NULL, path TEXT, country TEXT, referrer TEXT, created TEXT DEFAULT CURRENT_TIMESTAMP);
        """)
init_db()
def audit(action, entity=None, entity_id=None):
    with db() as c:
        c.execute("INSERT INTO audit(user_id,action,entity,entity_id,ip) VALUES(?,?,?,?,?)",
                  (session.get("uid"),action,entity,entity_id,request.headers.get("X-Forwarded-For",request.remote_addr)))
def body():
    return request.get_json(silent=True) or request.form.to_dict()
def clean(v, n=4000):
    return str(v or "").strip()[:n]
def fail(msg, code=400): return jsonify(ok=False,error=msg),code
def login_required(fn):
    @wraps(fn)
    def w(*a,**k):
        if not session.get("uid"): return fail("Authentication required",401)
        return fn(*a,**k)
    return w
def roles(*allowed):
    def deco(fn):
        @wraps(fn)
        @login_required
        def w(*a,**k):
            if session.get("role") not in allowed: return fail("Insufficient permission",403)
            return fn(*a,**k)
        return w
    return deco
@app.after_request
def headers(r):
    r.headers["X-Content-Type-Options"]="nosniff"
    r.headers["Referrer-Policy"]="strict-origin-when-cross-origin"
    r.headers["X-Frame-Options"]="DENY"
    r.headers["Permissions-Policy"]="camera=(), microphone=(), geolocation=()"
    return r
@app.get("/")
def home(): return send_from_directory(ROOT/"public","index.html")
@app.get("/<path:path>")
def static_files(path):
    p=ROOT/"public"/path
    if p.is_file(): return send_from_directory(ROOT/"public",path)
    abort(404)
@app.get("/api/health")
def health(): return jsonify(ok=True,service="LakshmiFlow International",database="connected")
@app.post("/api/setup")
def setup():
    d=body(); email=clean(d.get("email"),254).lower(); password=str(d.get("password") or "")
    name=clean(d.get("name"),120)
    with db() as c: count=c.execute("SELECT COUNT(*) FROM users WHERE role='owner'").fetchone()[0]
    if count: return fail("Owner setup is already completed",409)
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+",email) or len(password)<14 or not name:
        return fail("Valid email, name and a password of at least 14 characters are required")
    with db() as c:
        cur=c.execute("INSERT INTO users(email,password,name,role) VALUES(?,?,?,'owner')",(email,generate_password_hash(password)))
        uid=cur.lastrowid
    audit("initial_owner_created","user",uid)
    return jsonify(ok=True,message="Owner account created. Sign in now.")
@app.post("/api/login")
def login():
    d=body(); email=clean(d.get("email"),254).lower()
    with db() as c: u=c.execute("SELECT * FROM users WHERE email=? AND active=1",(email,)).fetchone()
    if not u or not check_password_hash(u["password"],str(d.get("password") or "")):
        time.sleep(.35); return fail("Invalid credentials",401)
    session.clear(); session["uid"]=u["id"]; session["role"]=u["role"]; session["name"]=u["name"]; session.permanent=True
    audit("login","user",u["id"])
    return jsonify(ok=True,user={"id":u["id"],"name":u["name"],"email":u["email"],"role":u["role"]})
@app.post("/api/logout")
@login_required
def logout():
    audit("logout"); session.clear(); return jsonify(ok=True)
@app.get("/api/me")
@login_required
def me(): return jsonify(ok=True,user={"id":session["uid"],"name":session["name"],"role":session["role"]})
@app.post("/api/inquiries")
def create_inquiry():
    d=body()
    required=["name","email"]
    if any(not clean(d.get(k)) for k in required) or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+",clean(d.get("email"),254)):
        return fail("Name and valid email are required")
    with db() as c:
        cur=c.execute("""INSERT INTO inquiries(name,company,email,country,port,product,quantity,message)
        VALUES(?,?,?,?,?,?,?,?)""",tuple(clean(d.get(k),lim) for k,lim in [("name",120),("company",200),("email",254),("country",100),("port",150),("product",200),("quantity",100),("message",4000)]))
    audit("inquiry_created","inquiry",cur.lastrowid)
    return jsonify(ok=True,id=cur.lastrowid,message="Inquiry received"),201
@app.get("/api/inquiries")
@roles("owner","sales","export","support")
def list_inquiries():
    with db() as c: rows=c.execute("SELECT * FROM inquiries ORDER BY id DESC LIMIT 500").fetchall()
    return jsonify(ok=True,items=[dict(x) for x in rows])
@app.patch("/api/inquiries/<int:i>")
@roles("owner","sales","export")
def update_inquiry(i):
    d=body(); status=clean(d.get("status"),30)
    if status not in ["new","assigned","quoted","follow_up","won","lost","closed"]: return fail("Invalid status")
    with db() as c: cur=c.execute("UPDATE inquiries SET status=?,assigned_to=? WHERE id=?",(status,d.get("assigned_to"),i))
    if not cur.rowcount: return fail("Inquiry not found",404)
    audit("inquiry_updated","inquiry",i); return jsonify(ok=True)
@app.post("/api/products")
@roles("owner","product")
def add_product():
    d=body()
    if not clean(d.get("name")) or not clean(d.get("category")): return fail("Product name and category are required")
    with db() as c:
        cur=c.execute("INSERT INTO products(category,name,model,finish,dimensions,specs,description,published) VALUES(?,?,?,?,?,?,?,?)",
          (clean(d["category"],100),clean(d["name"],200),clean(d.get("model"),100),clean(d.get("finish"),150),clean(d.get("dimensions"),300),clean(d.get("specs"),4000),clean(d.get("description"),4000),int(bool(d.get("published")))))
    audit("product_created","product",cur.lastrowid); return jsonify(ok=True,id=cur.lastrowid),201
@app.get("/api/products")
def products():
    with db() as c: rows=c.execute("SELECT * FROM products WHERE published=1 ORDER BY id DESC").fetchall()
    return jsonify(ok=True,items=[dict(x) for x in rows])
@app.get("/api/admin/products")
@roles("owner","product")
def admin_products():
    with db() as c: rows=c.execute("SELECT * FROM products ORDER BY id DESC").fetchall()
    return jsonify(ok=True,items=[dict(x) for x in rows])
@app.post("/api/meetings")
def meeting():
    d=body()
    if not clean(d.get("name")) or not clean(d.get("email")) or not clean(d.get("preferred_at")): return fail("Name, email and preferred date/time are required")
    with db() as c:
        cur=c.execute("INSERT INTO meetings(name,company,email,country,purpose,preferred_at,requirements) VALUES(?,?,?,?,?,?,?)",
          tuple(clean(d.get(k),lim) for k,lim in [("name",120),("company",200),("email",254),("country",100),("purpose",300),("preferred_at",80),("requirements",2000)]))
    audit("meeting_requested","meeting",cur.lastrowid); return jsonify(ok=True,id=cur.lastrowid,status="pending"),201
@app.get("/api/meetings")
@roles("owner","sales","support")
def meetings():
    with db() as c: rows=c.execute("SELECT * FROM meetings ORDER BY id DESC LIMIT 300").fetchall()
    return jsonify(ok=True,items=[dict(x) for x in rows])
@app.post("/api/jobs")
@roles("owner","hr")
def create_job():
    d=body()
    if not clean(d.get("title")): return fail("Job title required")
    with db() as c:
        cur=c.execute("INSERT INTO jobs(title,department,location,work_mode,description) VALUES(?,?,?,?,?)",
         tuple(clean(d.get(k),lim) for k,lim in [("title",200),("department",100),("location",150),("work_mode",50),("description",5000)]))
    audit("job_created","job",cur.lastrowid); return jsonify(ok=True,id=cur.lastrowid),201
@app.get("/api/jobs")
def jobs():
    with db() as c: rows=c.execute("SELECT id,title,department,location,work_mode,description FROM jobs WHERE active=1 ORDER BY id DESC").fetchall()
    return jsonify(ok=True,items=[dict(x) for x in rows])
@app.post("/api/applications")
def application():
    d=body()
    if not clean(d.get("name")) or not clean(d.get("email")) or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+",clean(d.get("email"),254)): return fail("Name and valid email required")
    with db() as c:
        cur=c.execute("INSERT INTO applications(job_id,name,email,phone,education,experience,skills,expected_salary,availability) VALUES(?,?,?,?,?,?,?,?,?)",
         (d.get("job_id"),clean(d.get("name"),120),clean(d.get("email"),254),clean(d.get("phone"),40),clean(d.get("education"),500),clean(d.get("experience"),1000),clean(d.get("skills"),1000),clean(d.get("expected_salary"),100),clean(d.get("availability"),100)))
    audit("application_received","application",cur.lastrowid); return jsonify(ok=True,id=cur.lastrowid),201
@app.get("/api/applications")
@roles("owner","hr")
def applications():
    with db() as c: rows=c.execute("SELECT * FROM applications ORDER BY id DESC LIMIT 500").fetchall()
    return jsonify(ok=True,items=[dict(x) for x in rows])
@app.post("/api/employees")
@roles("owner","hr")
def create_employee():
    d=body()
    if not clean(d.get("employee_code")): return fail("Employee ID required")
    with db() as c:
        cur=c.execute("INSERT INTO employees(user_id,employee_code,department,designation,joining_date,work_mode) VALUES(?,?,?,?,?,?)",
         (d.get("user_id"),clean(d.get("employee_code"),50),clean(d.get("department"),100),clean(d.get("designation"),100),clean(d.get("joining_date"),20),clean(d.get("work_mode") or "hybrid",20)))
    audit("employee_created","employee",cur.lastrowid); return jsonify(ok=True,id=cur.lastrowid),201
def employee_for_user():
    with db() as c: return c.execute("SELECT * FROM employees WHERE user_id=?",(session["uid"],)).fetchone()
@app.post("/api/attendance/check-in")
@roles("employee","owner","hr")
def checkin():
    e=employee_for_user()
    if not e: return fail("Employee profile is not linked to this account",404)
    d=body(); mode=clean(d.get("work_mode") or "office",20)
    if mode not in ["office","remote"]: return fail("Invalid work mode")
    with db() as c:
        cur=c.execute("INSERT INTO attendance(employee_id,check_in,work_mode,note) VALUES(?,?,?,?)",(e["id"],datetime.now(timezone.utc).isoformat(),mode,clean(d.get("note"),300)))
    audit("attendance_check_in","attendance",cur.lastrowid); return jsonify(ok=True,id=cur.lastrowid)
@app.post("/api/attendance/check-out")
@roles("employee","owner","hr")
def checkout():
    e=employee_for_user()
    if not e: return fail("Employee profile not linked",404)
    with db() as c:
        row=c.execute("SELECT * FROM attendance WHERE employee_id=? AND check_out IS NULL ORDER BY id DESC LIMIT 1",(e["id"],)).fetchone()
        if not row: return fail("No open check-in found",409)
        c.execute("UPDATE attendance SET check_out=? WHERE id=?",(datetime.now(timezone.utc).isoformat(),row["id"]))
    audit("attendance_check_out","attendance",row["id"]); return jsonify(ok=True)
@app.post("/api/leave")
@roles("employee","owner","hr")
def leave():
    e=employee_for_user()
    if not e: return fail("Employee profile not linked",404)
    d=body()
    if not all(clean(d.get(k)) for k in ["leave_type","start_date","end_date"]): return fail("Leave type and dates required")
    with db() as c:
        cur=c.execute("INSERT INTO leave_requests(employee_id,leave_type,start_date,end_date,reason) VALUES(?,?,?,?,?)",(e["id"],clean(d["leave_type"],40),clean(d["start_date"],20),clean(d["end_date"],20),clean(d.get("reason"),1000)))
    audit("leave_requested","leave",cur.lastrowid); return jsonify(ok=True,id=cur.lastrowid),201
@app.get("/api/leave")
@roles("owner","hr")
def all_leave():
    with db() as c: rows=c.execute("SELECT l.*,e.employee_code,e.department FROM leave_requests l JOIN employees e ON e.id=l.employee_id ORDER BY l.id DESC").fetchall()
    return jsonify(ok=True,items=[dict(x) for x in rows])
@app.patch("/api/leave/<int:i>")
@roles("owner","hr")
def review_leave(i):
    d=body(); status=clean(d.get("status"),20)
    if status not in ["approved","rejected"]: return fail("Status must be approved or rejected")
    with db() as c: cur=c.execute("UPDATE leave_requests SET status=?,reviewed_by=? WHERE id=?",(status,session["uid"],i))
    if not cur.rowcount: return fail("Leave request not found",404)
    audit("leave_reviewed","leave",i); return jsonify(ok=True)
@app.post("/api/tasks")
@roles("owner","hr","sales","export","product","marketing","support")
def create_task():
    d=body()
    if not clean(d.get("title")): return fail("Task title required")
    with db() as c:
        cur=c.execute("INSERT INTO tasks(title,details,assigned_employee,priority,due_date) VALUES(?,?,?,?,?)",(clean(d["title"],200),clean(d.get("details"),2000),d.get("assigned_employee"),clean(d.get("priority") or "normal",20),clean(d.get("due_date"),30)))
    audit("task_created","task",cur.lastrowid); return jsonify(ok=True,id=cur.lastrowid),201
@app.get("/api/tasks")
@roles("owner","hr","sales","export","product","marketing","support","employee")
def task_list():
    with db() as c: rows=c.execute("SELECT * FROM tasks ORDER BY id DESC LIMIT 500").fetchall()
    return jsonify(ok=True,items=[dict(x) for x in rows])
@app.patch("/api/tasks/<int:i>")
@roles("owner","hr","sales","export","product","marketing","support","employee")
def task_update(i):
    d=body(); status=clean(d.get("status"),30)
    if status not in ["open","in_progress","blocked","completed"]: return fail("Invalid task status")
    with db() as c: cur=c.execute("UPDATE tasks SET status=?,outcome=? WHERE id=?",(status,clean(d.get("outcome"),2000),i))
    if not cur.rowcount: return fail("Task not found",404)
    audit("task_updated","task",i); return jsonify(ok=True)
@app.post("/api/analytics/event")
def analytics_event():
    d=body(); event=clean(d.get("event"),80)
    if not event: return fail("Event required")
    with db() as c: c.execute("INSERT INTO events(event,path,country,referrer) VALUES(?,?,?,?)",(event,clean(d.get("path"),300),clean(d.get("country"),100),clean(d.get("referrer"),500)))
    return jsonify(ok=True)
@app.get("/api/analytics/summary")
@roles("owner","marketing","sales")
def analytics_summary():
    with db() as c:
        inquiries=c.execute("SELECT COUNT(*) n FROM inquiries").fetchone()["n"]
        meetings=c.execute("SELECT COUNT(*) n FROM meetings").fetchone()["n"]
        apps=c.execute("SELECT COUNT(*) n FROM applications").fetchone()["n"]
        events=c.execute("SELECT COUNT(*) n FROM events").fetchone()["n"]
        popular=c.execute("SELECT path,COUNT(*) n FROM events GROUP BY path ORDER BY n DESC LIMIT 10").fetchall()
    return jsonify(ok=True,summary={"inquiries":inquiries,"meetings":meetings,"applications":apps,"events":events,"top_paths":[dict(x) for x in popular]})
@app.post("/api/catalogues")
@roles("owner","product","marketing")
def catalogue_upload():
    f=request.files.get("file"); title=clean(request.form.get("title"),200)
    if not f or not title: return fail("Title and PDF file required")
    if not f.filename.lower().endswith(".pdf") or f.mimetype not in ["application/pdf","application/octet-stream"]: return fail("Only PDF catalogues are accepted")
    name=secrets.token_hex(16)+"_"+secure_filename(f.filename)
    f.save(UPLOADS/name)
    with db() as c: cur=c.execute("INSERT INTO catalogues(title,volume,filename,published) VALUES(?,?,?,?)",(title,clean(request.form.get("volume"),100),name,int(request.form.get("published")=="1")))
    audit("catalogue_uploaded","catalogue",cur.lastrowid); return jsonify(ok=True,id=cur.lastrowid),201
@app.get("/api/catalogues")
def catalogues():
    with db() as c: rows=c.execute("SELECT id,title,volume,filename FROM catalogues WHERE published=1 ORDER BY id DESC").fetchall()
    return jsonify(ok=True,items=[{"id":x["id"],"title":x["title"],"volume":x["volume"],"url":"/api/catalogues/"+str(x["id"])+"/file"} for x in rows])
@app.get("/api/catalogues/<int:i>/file")
def catalogue_file(i):
    with db() as c: row=c.execute("SELECT filename FROM catalogues WHERE id=? AND published=1",(i,)).fetchone()
    if not row: abort(404)
    return send_from_directory(UPLOADS,row["filename"],as_attachment=True)
@app.get("/api/admin/overview")
@roles("owner","hr","sales","export","marketing")
def overview():
    with db() as c:
        tables=["users","inquiries","products","meetings","employees","leave_requests","attendance","tasks","jobs","applications","catalogues"]
        counts={t:c.execute("SELECT COUNT(*) n FROM "+t).fetchone()["n"] for t in tables}
    return jsonify(ok=True,counts=counts)
@app.errorhandler(413)
def too_large(e): return fail("Upload exceeds 25 MB limit",413)
@app.errorhandler(404)
def not_found(e): return jsonify(ok=False,error="Not found"),404
if __name__=="__main__":
    app.run(host="127.0.0.1",port=int(os.environ.get("PORT",5000)),debug=False)
